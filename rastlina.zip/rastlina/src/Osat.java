//naložimo paket z V/I napravami
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;


		class Osat extends Plevel{

			public void izpuli() {
				jeViden = false;
			}
		}


